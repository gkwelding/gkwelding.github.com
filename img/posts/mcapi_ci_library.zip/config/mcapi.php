<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['mcapi_apikey'] = 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx';

$config['mcapi_secure'] = true;