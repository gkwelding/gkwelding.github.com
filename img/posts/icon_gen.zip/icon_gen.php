<?php
	$color = $_GET['color'];
	if (!$color) {$color = "ff776b";} //default google map color
	
	$color = str_replace("#", "", $color);
	$string = strtoupper($_GET['text']);
	
	$font = 'arial.ttf';
	
	if (strlen($string) == 1) {
		$fontsize = 9;
	} else if (strlen($string) == 2) {
		$fontsize = 6.5;
	} else {
		$string = substr($string,0,2);
		$fontsize = 6.5;
	}

	//unfortunately we still must do some offsetting
	if($fontsize == 9){
		switch (ord(substr($string,0,1))) {
			case 49: //1
				$xoffset = 3;
				$yoffset = 1;
				break;
			case 50: //2
			case 51: //3
			case 52: //4
			case 53: //5
			case 55: //7
				$xoffset = 5;
				$yoffset = 1;
				break;
			case 54: //6
			case 56: //8
			case 57: //9
			case 48: //0
				$xoffset = 4;
				$yoffset = 1;
				break;
			case 65: //A
				$xoffset = 6;
				$yoffset = 1;
				break;
			case 89: //Y
				$xoffset = 6;
				$yoffset = 0;
				break;
			case 68: //D
			case 69: //E
			case 70: //F
			case 72: //H
			case 73: //I
			case 75: //K
			case 76: //L
			case 78: //N
			case 70: //O
			case 80: //P
			case 82: //R
			case 84: //T
			case 85: //U
			case 86: //V
			case 87: //W
			case 88: //X
				$xoffset = 5;
				$yoffset = 0;
				break;
			case 81: //Q
				$xoffset = 5;
				$yoffset = 1;
				break;
			default:
				$xoffset = 4;
				$yoffset = 1;
				break;
		}
	} else {
		switch (ord(substr($string,0,1))) {
			case 49: //1
				$xoffset = 4;
				$yoffset = 1;
				break;
			case 50: //2
			case 51: //3
			case 54: //6
			case 55: //7
			case 56: //8
			case 57: //9
				$xoffset = 5;
				$yoffset = 1;
				break;
			case 52: //4
			case 53: //5
			case 48: //0
				$xoffset = 4;
				$yoffset = 1;
				break;
			case 65: //A
			case 67: //C
			case 86: //V
			case 87: //W
			case 88: //X
			case 89: //Y
				$xoffset = 5;
				$yoffset = 1;
				break;
			case 68: //D
			case 69: //E
			case 70: //F
			case 72: //H
			case 73: //I
			case 75: //K
			case 76: //L
			case 77: //M
			case 78: //N
			case 70: //O
			case 80: //P
			case 82: //R
			case 84: //T
			case 85: //U
			case 90: //Z
				$xoffset = 4;
				$yoffset = 1;
				break;
			case 81: //Q
				$xoffset = 5;
				$yoffset = 2;
				break;
			default:
				$xoffset = 5;
				$yoffset = 1;
				break;
		}
	}

	$bbox = imagettfbbox($fontsize, 0, $font, $string);
	$width = $bbox[2] - $bbox[0] + 1;
	$height = $bbox[1] - $bbox[7] + 1;

	$image_name = "http://chart.apis.google.com/chart?cht=mm&chs=30x30&chco=$color,$color,000000&ext=.png";
	
	$im = imagecreatefrompng($image_name);
	imageAlphaBlending($im, true);
	imageSaveAlpha($im, true);
	$black = imagecolorallocate($im, 0, 0, 0);

	imagettftext($im, $fontsize, 0, 11 - $width/2 + $xoffset, 9 + $height/2 - $yoffset, $black, $font, $string);

	header("Content-type: image/png");
	imagepng($im);
	imagedestroy($im);
?>
