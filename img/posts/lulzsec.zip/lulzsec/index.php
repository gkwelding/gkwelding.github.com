<?php
error_reporting(0);
@ini_set(‘display_errors’, 0);

$link = mysql_connect('localhost', '', '');

if (!$link) {
	die('Not connected : ' . mysql_error());
}

// make foo the current db
$db_selected = mysql_select_db('lulzsec', $link);
if (!$db_selected) {
	die ('Can\'t use lulzsec : ' . mysql_error());
}

$contents="<html>
<head>
	<style type='text/css' media='screen'>
		body {
			font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
			color: #666;
			padding: 10px;
		}
		
		h1 {
			margin-top: 0;
		}
		
		ul {
			list-style: none;
			padding: 0;
			margin: 0;
		}
		
		li {
			margin-bottom: 20px;
			clear: both;
		}
		
		label {
			font-size: 10px;
			font-weight: bold;
			text-transform: uppercase;
			display: block;
			margin-bottom: 3px;
			clear: both;
		}
		
		div.loginBox {
			margin: auto;
			width: 475px;
			padding: 5px;
			margin-bottom: 5px;
			background-color: grey;
			-webkit-border-radius: 15px;
			-moz-border-radius: 15px;
			border-radius: 15px;
		}
		
		div.resultsBox {
			margin: auto;
			width: 475px;
			padding: 5px;
			background-color: grey;
			-webkit-border-radius: 15px;
			-moz-border-radius: 15px;
			border-radius: 15px;
		}
		
		div.noteContainer {
			margin: auto;
			width: 475px;
			padding: 5px;
			background-color: #000000;
			margin-bottom: 5px;
			-webkit-border-radius: 15px;
			-moz-border-radius: 15px;
			border-radius: 15px;
		}
		
		div.loginBox td {
			color: #FFFFFF;
		}
		
		div.resultsBox td {
			color: #FFFFFF;
			font-size: 10px;
		}
		
		div.noteContainer p {
			color: #FFFFFF;
			font-size: 10px;
		}

		a:link {
			text-decoration: none;
			color: #4282D3;
		}
		
		a:visited {
			text-decoration: none;
			color: #4282D3;
		}
		
		a:active {
			text-decoration: none;
			color: #4282D3;
		}
		
		a:hover {
			text-decoration: underline;
			color: red;
		}
	</style>
</head>
<body>
";

echo '<div class="noteContainer">';
echo '<p>Use this tool to easily search for your friends in the latest list of 62,000 email addresses and passwords released by <a href="http://lulzsecurity.com/" target="_blank">Lulzsec</a>. I do not store the passwords here, just to means to find out if you should go and check the list ;)</p>';
echo '<p>Just enter your email address and password below, I use openInviter to pull your contacts from your account and cross-reference them against the database.</p>';
echo '<p>If there\'s enough interest in this \'tool\' then I\'ll update it with more lists as they\'re released (I\'ll also port the backlog of old lists) and maybe implement some more search features.</p>';
echo '<p>Garry Welding<br /><a href="http://www.in-the-attic.co.uk" target="_blank">www.in-the-attic.co.uk</a><br /><a href="http://www.twitter.com/GarryWelding">twitter.com/GarryWelding</a></p>';
echo '<p>** Quick update, the pron.com (10/06/2011) email addresses (circa 25,000) have been added to the database.</p>';
echo '<p>** Another database update, this time including email addresses from Sonypictures.com AutoTrader users (02/06/2011)</p>';
echo '<p>** Another database update, this time including email addresses from Sonypictures.com Summer of Relentless Beauty users (02/06/2011)</p>';
echo '<p>** Another database update, this time including email addresses from PBS Pressroom users (30/05/2011)</p>';
echo '</div>';

include('OpenInviter/openinviter.php');

$inviter=new OpenInviter();
$oi_services=$inviter->getPlugins();

function ers($ers) {
	if (!empty($ers)) {
		$contents="<table cellspacing='0' cellpadding='0' style='border:1px solid red;' align='center'><tr style=\"background-color:#FFFFFF;\"><td valign='middle' style='padding:3px' valign='middle'><img src='/lulzsec/OpenInviter/imgs/ers.gif'></td><td valign='middle' style='color:red;padding:5px;'>";
		foreach ($ers as $key=>$error)
			$contents.="{$error}<br >";
		$contents.="</td></tr></table><br >";
		return $contents;
	}
}

$step='get_contacts';

$ers=array();
$import_ok=false;
$done=false;

if ($_SERVER['REQUEST_METHOD']=='POST') {
	if ($step=='get_contacts') {
		if (empty($_POST['email_box']) && !isset($_POST['search_term'])) {
			$ers['email']="Email missing !";
		} else if(!isset($_POST['search_term'])) {
			$provider=$inviter->getPluginByDomain($_POST['email_box']);
			if (!empty($provider)) {
				if (isset($oi_services['email'][$provider])) $plugType='email';
				elseif (isset($oi_services['social'][$provider])) $plugType='social';
				else $plugType='';
			} else {
				$ers['email']="Email missing !";
			}
		}
		
		if (empty($_POST['password_box']) && !isset($_POST['search_term'])) $ers['password']="Password missing !";
		
		if (count($ers)==0 && !isset($_POST['search_term'])) {			
			$inviter->startPlugin($provider);
			$internal=$inviter->getInternalError();
			if ($internal) {
				$ers['inviter']=$internal;
			} elseif (!$inviter->login($_POST['email_box'],$_POST['password_box'])) {
				$internal=$inviter->getInternalError();
				$ers['login']=($internal?$internal:"Login failed. Please check the email and password you have provided and try again later !");
			} elseif (false===$contacts=$inviter->getMyContacts()) {
				$ers['contacts']="Unable to get contacts !";
			} else {
				$import_ok=true;
				$_POST['oi_session_id']=$inviter->plugin->getSessionID();
				$_POST['message_box']='';
			}
		}
	}
} else {
	$_POST['email_box']='';
	$_POST['password_box']='';
}

$contents .= '<div class="loginBox">';
$contents .= "<form action='' method='POST' name='openinviter'>".ers($ers);
$contents .= "<table align='center' class='thTable' cellspacing='2' cellpadding='0' style='border:none;'>
				<tr><td align='right'><label for='email_box'>Email</label></td><td><input type='text' name='email_box' size='50' value='{$_POST['email_box']}'></td></tr>
				<tr><td align='right'><label for='password_box'>Password</label></td><td><input type='password' name='password_box' size='50' value='{$_POST['password_box']}'></td></tr>			
				<tr><td colspan='2' align='center'><input type='submit' name='import' value='Search Contacts'></td></tr>
			</table>
			<input type='hidden' name='step' value='get_contacts'>";
$contents .= "</form>";
$contents .= "<form action='' method='POST' name='openinviter'>";
$contents .= "<table align='center' class='thTable' cellspacing='2' cellpadding='0' style='border:none;'>
				<tr><td align='right'></td><td><input type='text' name='search_term' size='60' value='{$_POST['search_term']}'></td></tr>
				<tr><td colspan='2' align='center'><input type='submit' name='import' value='Search'></td></tr>
			</table>
			<input type='hidden' name='step' value='search'>";
$contents .= "</form>";
$contents .= '</div>';

echo $contents;

$emails = array();

if ($import_ok) {
	echo '<div class="resultsBox">';
	echo '<table cellspacing="0" cellpadding="0" align="center">';
	
	if ($inviter->showContacts()) {
		if (count($contacts)!=0) {
			foreach ($contacts as $email=>$name) {
				$emails[] = mysql_real_escape_string($email,$link);
			}
			
			$sql = 'SELECT * from lulzsec WHERE email LIKE "'.implode('" OR email LIKE "',$emails).'"';
			
			$results = mysql_query($sql,$link);
			
			if(mysql_num_rows($results) == 0) {
				echo '<tr><td>Sorry but I couldn\'t find anybody on your contact list in the database.</td></tr>';
			} else {
				$i = 1;
				while ($row = mysql_fetch_assoc($results)) {
					echo '<tr><td>'.$i.'. '.$row["email"].' ('.$row['source'].')</td></tr>';
					$i++;
				}
			}
		}
	}
	
	echo '</table>';
	echo '</div>';
}

if (isset($_POST['search_term']) && trim($_POST['search_term']) != '') {
	echo '<div class="resultsBox">';
	echo '<table cellspacing="0" cellpadding="0" align="center">';
			
	$sql = 'SELECT * from lulzsec WHERE LOWER(email) LIKE "%'.mysql_real_escape_string(strtolower(trim($_POST['search_term'])),$link).'%"';
	
	$results = mysql_query($sql,$link);
	
	if(mysql_num_rows($results) == 0) {
		echo '<tr><td>Sorry but I couldn\'t find anybody to match your query in the database.</td></tr>';
	} else {
		$i = 1;
		while ($row = mysql_fetch_assoc($results)) {
			echo '<tr><td>'.$i.'. '.$row["email"].' ('.$row['source'].')</td></tr>';
			$i++;
		}
	}
	
	mysql_free_result($results);
	
	echo '</table>';
	echo '</div>';
}

mysql_close($link);

echo '</body>';
echo '</html>';