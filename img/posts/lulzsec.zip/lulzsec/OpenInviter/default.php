<?php
echo "OpenInviter - import addressbook/contacts from different email providers like Yahoo, Gmail, Hotmail, Live etc. using different CMS software like Drupal, Joomla etc. or forum software like PHPBB, SMF etc. available at <a href='openinviter.com'>http://openinviter.com</a>";
?>