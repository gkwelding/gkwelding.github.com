<?php
$openinviter_settings=array(
	'username'=>"gwelding", 
	'private_key'=>"e1c85bba67046a30980df18c7f21cd9c", 
	'cookie_path'=>"/tmp", 
	'message_body'=>"You are invited to www.in-the-attic.co.uk", 
	'message_subject'=>" is inviting you to www.in-the-attic.co.uk", 
	'transport'=>"curl", 
	'local_debug'=>"on_error", 
	'remote_debug'=>"", 
	'hosted'=>"", 
	'proxies'=>array(),
	'stats'=>"0", 
	'plugins_cache_time'=>"1800", 
	'plugins_cache_file'=>"oi_plugins.php", 
	'update_files'=>"1");
?>